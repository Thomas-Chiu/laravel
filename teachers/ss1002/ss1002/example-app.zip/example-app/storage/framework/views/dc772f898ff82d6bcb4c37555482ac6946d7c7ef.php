<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    hello init pchome 商品介紹頁面
    <br><br>
    <a href="<?php echo e(route('go_test')); ?>">我要買這個test商品</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\example-app\resources\views/init.blade.php ENDPATH**/ ?>