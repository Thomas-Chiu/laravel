<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    photo_page
    <br>
    <br>
    <table border="1px" width="80%">
        <tr>
            <td>name</td>
            <td>url</td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\example-app\resources\views/photoPage.blade.php ENDPATH**/ ?>