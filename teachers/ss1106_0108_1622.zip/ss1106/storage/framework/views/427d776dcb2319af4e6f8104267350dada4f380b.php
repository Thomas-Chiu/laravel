<table>
    <thead>
    <tr>
        <th>Name</th>
        <th>Phone</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student->name); ?></td>
            

            <?php if(!empty($student->phoneRelation->phone)): ?>
                <td><?php echo e($student->phoneRelation->phone); ?></td>
            <?php else: ?>
            <td>no data</td>
        <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\laravel\ss1106\resources\views/student/invoices.blade.php ENDPATH**/ ?>