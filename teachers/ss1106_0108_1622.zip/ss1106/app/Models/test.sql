SELECT * FROM students ;
