<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>
        result99
    </h2>
    <?php
        // dd($data);
    ?>
    <?php for($i = 1; $i <= $data['num1']; $i++): ?>
        <?php for($j = 1; $j <= $data['num2']; $j++): ?>
            <?php echo e($i); ?> * <?php echo e($j); ?> = <?php echo e($i * $j); ?> &nbsp;&nbsp;&nbsp;
        <?php endfor; ?>
        <br>
    <?php endfor; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\ss1023\resources\views/car/result99.blade.php ENDPATH**/ ?>