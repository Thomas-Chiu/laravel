<!-- resources/views/child.blade.php -->



<?php $__env->startSection('title123', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

    <p>子版的內容</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>This is my body content.</p>
    <h1>test content </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutsFolder.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ss1023\resources\views/child.blade.php ENDPATH**/ ?>