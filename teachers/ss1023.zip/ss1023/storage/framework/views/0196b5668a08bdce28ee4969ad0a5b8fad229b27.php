<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>
    <?php
        // $url = asset('assets/css/style.css');
        // dd($url);
        // dd($data);
        // dd($data[0]['id']);
    ?>
    <table>
        <tr>
            <th>id</th>
            <th>name</th>
        </tr>
        <?php $__currentLoopData = $data['myArr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item['id']); ?></td>
                <td><?php echo e($item['name']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\ss1023\resources\views/car/result.blade.php ENDPATH**/ ?>