
<?php $__env->startSection('title123','55688'); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

    <p>page2 appended to the master sidebar.</p>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <h3>page1</h3>
    <p>test test</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutsFolder.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ss1023\resources\views/page/page2.blade.php ENDPATH**/ ?>