<!DOCTYPE html>
<html>
    <head>
        <title>App Name - <?php echo $__env->yieldContent('title123'); ?></title>
    </head>
    <body>
        <?php $__env->startSection('sidebar'); ?>
            <h2>主板的內容</h2>
        <?php echo $__env->yieldSection(); ?>

        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\ss1023\resources\views/layoutsFolder/app.blade.php ENDPATH**/ ?>