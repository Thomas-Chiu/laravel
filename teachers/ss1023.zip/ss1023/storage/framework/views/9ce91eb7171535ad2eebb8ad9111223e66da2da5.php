<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>calculator</h2>
    <hr>
    <p>num1 = <?php echo e($data['num1']); ?></p>
    <p>num2 = <?php echo e($data['num2']); ?></p>
    <p>mySelect = <?php echo e($data['mySelect']); ?></p>
    <p>result = <?php echo e($data['result']); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\ss1023\resources\views/car/calResult.blade.php ENDPATH**/ ?>