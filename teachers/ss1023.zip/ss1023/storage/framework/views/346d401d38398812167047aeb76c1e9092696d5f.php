<!DOCTYPE html>
<html>
    <head>
        <title>App Name - <?php echo $__env->yieldContent('title123'); ?></title>
    </head>
    <body>
        <?php $__env->startSection('sidebar'); ?>
            This is the master sidebar.
        <?php echo $__env->yieldSection(); ?>

        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\ss1023\resources\views/layouts/app.blade.php ENDPATH**/ ?>